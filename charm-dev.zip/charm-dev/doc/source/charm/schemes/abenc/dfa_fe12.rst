
dfa_fe12
=========================================
.. automodule:: dfa_fe12
    :show-inheritance:
    :members:
    :undoc-members:
