
sigma1
=========================================
.. automodule:: sigma1
    :show-inheritance:
    :members:
    :undoc-members:
