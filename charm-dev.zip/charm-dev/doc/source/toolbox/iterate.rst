
iterate
=========================================
.. automodule:: iterate
    :show-inheritance:
    :members:
    :undoc-members:
