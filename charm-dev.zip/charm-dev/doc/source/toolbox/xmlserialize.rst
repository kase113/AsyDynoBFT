
xmlserialize
=========================================
.. automodule:: xmlserialize
    :show-inheritance:
    :members:
    :undoc-members:
