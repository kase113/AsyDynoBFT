
matrixops
=========================================
.. automodule:: matrixops
    :show-inheritance:
    :members:
    :undoc-members:
